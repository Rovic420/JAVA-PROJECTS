public class Main {
  String fname = "Rovic";
  String lname = "Deloy";
  int age = (20);
  
  public static void main(String[] args) {
    
    Main Person = new Main();
    
    System.out.println("Your name is: " + Person.fname + " " + Person.lname);
    System.out.println(" ====================");
    System.out.println("You are : " + Person.age + " years old!");
    }
  }